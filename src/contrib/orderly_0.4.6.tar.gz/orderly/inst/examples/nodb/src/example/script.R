png("mygraph.png")
plot(1:10)
dev.off()
