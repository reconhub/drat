# orderly: data

This directory contains the results of queries run against the database, in csv and rds form.  Reports will reference these by the hashes.  This directory could grow quite large over time.

(you can delete or edit this file safely)
