vaultr::vault_test_server_stop()
