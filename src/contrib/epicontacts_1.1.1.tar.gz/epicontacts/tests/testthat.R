library(testthat)
library(epicontacts)

test_check("epicontacts")
