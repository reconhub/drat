library(testthat)
library(dibbler)

test_check("dibbler")
