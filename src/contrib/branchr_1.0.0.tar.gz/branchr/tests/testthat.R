library(testthat)
library(branchr)

test_check("branchr")
