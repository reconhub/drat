#' Smallpox in Abakaliki, Nigeria, 1967
#'
#' These data comprise of 32 cases of smallpox in Abakaliki, Nigeria in 1967, first described
#' by Thompson and Foege (1968), which occurred predominantly in a religious group that
#' refused medical interventions.
#'
#' @docType data
#'
#' @format A data frame with 32 rows and 8 columns
#' \describe{
#'   \item{case_ID}{Case identification number}
#'   \item{date_of_onset}{Date of onset of symptoms}
#'   \item{age}{Age in years}
#'   \item{gender}{Gender: female (f) or male (m) (factor)}
#'   \item{vaccinated}{Previously vaccinated: no (n) or yes (y) (factor)}
#'   \item{vaccscar}{Vaccination scar present: no (n) or yes (y) (factor)}
#'   \item{ftc}{Member of the Faith Tabernacle: no (n) or yes (y) (factor)}
#'   \item{compound}{Compound number (factor)}
#' }
#'
#' @rdname smallpox_abakaliki_1967
#'
#' @author Data from Thompson and Foege (1968).
#' Transfer to R and documentation by Simon Frost \cr
#' (\email{sdwfrost@@gmail.com}).
#'
#' @source \url{http://apps.who.int/iris/bitstream/10665/67462/1/WHO_SE_68.3.pdf}
#'
#' @references
#' D. Thompson and W. Foege. 1968. Faith Tabernacle smallpox epidemic.
#' Abakaliki, Nigeria. World Health Organization, 3:1–9
#'
#' @examples
#' ## show first few cases
#' head(smallpox_abakaliki_1967)
#'
"smallpox_abakaliki_1967"
