library(testthat)
library(epitrix)
library(distcrete)

test_check("epitrix")
