library(testthat)
library(vimes)

test_check("vimes")
