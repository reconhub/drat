## ---- echo = FALSE-------------------------------------------------------

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", 
  fig.width = 6, 
  fig.height = 6, 
  fig.path = "figs-demo/"
)


## ---- data---------------------------------------------------------------
set.seed(2)
dat1 <- rnorm(30, c(0,1,6))
dat2 <- rnorm(30, c(0,0,1))
dat3 <- rnorm(30, c(8,1,2))
x <- lapply(list(dat1, dat2, dat3), dist)

## ---- vimesdata----------------------------------------------------------
library(vimes)

x <- vimes_data(x)
plot(x)


## ---- vimes--------------------------------------------------------------

res <- vimes(x, cutoff = c(2,4,2))
names(res)

res$graph
res$clusters

## ---- res----------------------------------------------------------------
plot(res$graph, main="Main graph")
for(i in 1:3) {
plot(res$separate_graphs[[i]]$graph, main = paste("Graph from data", i))
}

