## ---- echo = FALSE-------------------------------------------------------

knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>", 
  fig.width = 6, 
  fig.height = 5, 
  fig.path = "figs-dist/"
)


## ---- serial-------------------------------------------------------------

si <- distcrete::distcrete("gamma", 1L,
                           shape = 10,
			   rate = 1.2)$d(1:20)

plot(si, type = "h", lwd = 10, lend=2,
     xlab = "Days after onset",
     main = "Serial interval distribution")


## ---- convolve-----------------------------------------------------------

si_10 <- vimes:::convolve_empirical(si, 10, TRUE)


## ---- convolve2----------------------------------------------------------

head(si_10)
apply(si_10, 2, sum)

matplot(si_10[1:120,], type = "l", lty = 1, lwd = 2, col = rainbow(10),
	xlab = "Days after onset",
	main = "Serial interval, k = 1, ..., 10 missing cases")
mtext("from k = 1 (red) to k = 10 (purple)", 3)


## ---- weights------------------------------------------------------------

w <- vimes:::get_weights(0.6, 10)
plot(w, type = "h", xlab = "k", ylab = "weight",
     lwd = 10, lend = 2, main = "Weights")


## ---- final--------------------------------------------------------------

d_final <- dempiric(si, 0.6)
head(d_final)
sum(d_final)

pal <- colorRampPalette(c("navy", "lightblue", "grey"))

plot(d_final[1:80], type = "h", lwd = 3, lend = 2,
     col = pal(80), xlab = "Days after onset",
     main = "Distributions of temporal distances for pi = 60%")


