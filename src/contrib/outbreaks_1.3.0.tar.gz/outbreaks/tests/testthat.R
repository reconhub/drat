library(testthat)
library(outbreaks)

test_check("outbreaks")
