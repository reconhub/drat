shiny::addResourcePath("recon.ui", system.file("assets", package = "recon.ui"))
linelist_examples <- list(
  mers_korea_2015 = outbreaks::mers_korea_2015$linelist,
  ebola_sim = outbreaks::ebola_sim$linelist)
contacts_examples <- list(
  mers_korea_2015 = outbreaks::mers_korea_2015$contacts,
  ebola_sim = outbreaks::ebola_sim$contacts)