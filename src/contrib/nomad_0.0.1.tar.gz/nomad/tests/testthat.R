library(testthat)
library(nomad)

test_check("nomad")
