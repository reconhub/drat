library(testthat)
library(recontools)

test_check("recontools")
