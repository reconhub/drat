library(testthat)
library(earlyR)

test_check("earlyR")
